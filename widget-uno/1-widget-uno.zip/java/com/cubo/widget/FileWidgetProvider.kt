package com.cubo.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import java.io.File

class FileWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (widgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, widgetId)
        }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, widgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_layout)

        val filePath = "/data/data/com.termux/files/home/ficheiro-monitorizado.txt"
        val file = File(filePath)

        val color = if (file.exists()) {
            val lastModified = file.lastModified()
            val diffMinutes = (System.currentTimeMillis() - lastModified) / 60000
            if (diffMinutes < 5) Color.GREEN else Color.RED
        } else {
            Color.GRAY
        }

        views.setInt(R.id.widget_background, "setBackgroundColor", color)

        val intent = Intent(Intent.ACTION_MAIN)
        intent.setClassName("com.termux", "com.termux.app.TermuxActivity")
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.widget_background, pendingIntent)

        appWidgetManager.updateAppWidget(widgetId, views)
    }
}
